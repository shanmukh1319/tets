module.exports = function(RED) {
    function CheckParameterNode(config) {
       RED.nodes.createNode(this, config);
       const node=this;
       const globalContext = node.context().global;

        node.on('input',async function(msg) {
            const redis = globalContext.get('redis');
            if(!globalContext.get('redisConnected')){
                redis.connect()
            }

            redis.on('connect',async() => {
                globalContext.set('redisConnected', true);
                console.log("Connected to Redis")
            })

            redis.on("error",(err) => {
                console.log("eeroor in redis connection")
            })

            msg.payload['param_exists']=0;
           
            if(config && config['parameters']){
                const parameters=config.parameters.split(",");
                let checkParameters = parameters.filter((param) => msg.payload.parameters.indexOf(param) != -1);
                if(checkParameters.length>0){
                    msg.payload['param_exists']=1;
                }
            }
            node.send(msg);
        });
    }
    RED.nodes.registerType("checkParameters", CheckParameterNode);
}
