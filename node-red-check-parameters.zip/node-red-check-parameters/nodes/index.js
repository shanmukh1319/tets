module.exports = function(RED) {
    RED.nodes.registerType("checkParameters", require("./check-parameters/check-parameters.js"));
    RED.nodes.registerType("getLatestMotorValue", require("./get-motor-values/motor-value.js"));
};
