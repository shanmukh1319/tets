module.exports = function(RED) {
    function evaluateSpeedNode(config) {
       RED.nodes.createNode(this, config);
       const node=this;
       const globalContext = node.context().global;

        node.on('input',async function(msg) {
            const redis = globalContext.get('redis');
            node.log(`data of messag received for evaluation ${msg}`)
            let speed_val1 = msg.payload.speed_latest;
            let speed_val2 = msg.payload.speed_second_latest;
            node.log(`Speed 1 Value ${speed_val1}`)
            node.log(`Speed 2 Value ${speed_val2}`)
            if (speed_val1==1){
                msg.speed_value = 0;
            }
            if (speed_val1!=speed_val2 && speed_val1==0){
                msg.speed_value = 1;
            }
            if (speed_val1==speed_val2 && speed_val1==0){
                msg.speed_value = 2;
            }
            node.send(msg);
            console.log("message published for speed",msg.speed_value)
        });
    }
    RED.nodes.registerType("evaluateSpeed", evaluateSpeedNode);
}
