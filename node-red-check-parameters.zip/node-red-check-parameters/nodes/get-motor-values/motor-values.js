const moment=require("moment-timezone");
module.exports = function(RED) {
    function getMotorValueNode(config) {
       RED.nodes.createNode(this, config);
       const node=this;
       const globalContext = node.context().global;

        node.on('input',async function(msg) {
            const redis = globalContext.get('redis');
            const streamKey = `${config['machineCode']}@${moment(config['startDate']).format("YYYY_MM_DD_HH_mm")}@${moment(config['endDate']).format("YYYY_MM_DD_HH_mm")}`
            const entries = await redis.xRevRange(streamKey, '+', '-', { COUNT: 2 });
            const values =entries[0]['message']['values'].split(",").map(Number)
            if(values.length>0){
                if(config['option'] == "latest"){
                    msg.payload.motor_latest = values[values.length-1];
                    msg.topic='motor_latest';
                }else{
                    msg.topic='motor_second_latest';
                    if(values.length>1){
                        msg.payload.motor_second_latest =  values[values.length-2];
                    }
                }
                node.send(msg);
            }
        });
    }
    RED.nodes.registerType("getMotorValue", getMotorValueNode);
}
