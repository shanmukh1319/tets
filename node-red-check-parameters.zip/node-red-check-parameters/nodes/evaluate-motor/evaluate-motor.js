module.exports = function(RED) {
    function evaluateMotorNode(config) {
       RED.nodes.createNode(this, config);
       const node=this;
       const globalContext = node.context().global;

        node.on('input',async function(msg) {
            const redis = globalContext.get('redis');
            node.log(`data of messag received for evaluation ${msg}`)
            let motor_val1 = msg.payload.motor_latest;
            let motor_val2 = msg.payload.motor_second_latest;
            node.log(`Motor 1 Value ${motor_val1}`)
            node.log(`Motor 2 Value ${motor_val2}`)
            if (motor_val1==1){
                msg.motor_value = 0;
            }
            if (motor_val1!=motor_val2 && motor_val1==0){
                msg.motor_value = 1;
            }
            if (motor_val1==motor_val2 && motor_val1==0){
                msg.motor_value = 2;
            }
            node.send(msg);
            console.log("message published",msg.motor_value)
        });
    }
    RED.nodes.registerType("evaluateMotor", evaluateMotorNode);
}
